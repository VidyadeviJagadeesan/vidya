export class Movie{
    name:string;
    image:string;
}